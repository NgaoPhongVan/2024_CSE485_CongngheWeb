<?php
define('ROOT',dirname(__DIR__));

define('DB_host','localhost');
define('DB_name','phonebook');
define('DB_user','root');
define('DB_pass','');

