<?php
    require_once ROOT.'/models/department.php';
    require_once ROOT.'/config/database.php';
    class departmentservice
    {
        public function Getalldepartment()
        {
            $dbconnection = new DBconnection();
            $conn = $dbconnection->getconnection();
            if ($conn) {
                $sql = 'SELECT * FROM departments';
                $result = $conn->query($sql);
                $departments = [];
                while ($row = $result->fetch()) {
                    $department = new department($row['DepartmentID'], $row['DepartmentName'], $row['Address'], $row['Email'], $row['Phone'], $row['Logo'], $row['Website'], $row['ParentDepartmentID']);
                    $departments[] = $department;
                }
//                mysqli_free_result($result);
                return $departments;
            }

        }

        public function AddDepartment($id,$name, $phone, $address, $email) {
            try {
                // Thiết lập chế độ lỗi để PDO ném ra các ngoại lệ nếu có lỗi
                $dbconnection = new DBconnection();
                $conn = $dbconnection->getconnection();
                // Chuẩn bị truy vấn SQL
                $sqlcheck = "SELECT *FROM departments where DepartmentID = '$id' ";
                $result_check = $conn->query($sqlcheck);
                echo '<pre>';
                print_r($result_check);
                echo '</pre>';
                $count_resutl = $result_check->rowCount();
                if($count_resutl > 0){
                    echo "id đã tồn tại";
                    exit;
               }
                $sql = "INSERT INTO departments (DepartmentID,DepartmentName, Phone, Address, Email) VALUES (:id,:name, :phone, :address, :email)";
                $stmt = $conn->prepare($sql);

                // Bind các tham số với giá trị thực
                $stmt->bindParam(':id', $id);
                $stmt->bindParam(':name', $name);
                $stmt->bindParam(':phone', $phone);
                $stmt->bindParam(':address', $address);
                $stmt->bindParam(':email', $email);

                // Thực thi truy vấn
                $stmt->execute();

                // Kiểm tra xem có bản ghi nào bị ảnh hưởng không
                if ($stmt->rowCount() > 0) {
                    echo "Thêm bộ phận thành công";
                } else {
                    echo "Không thể thêm bộ phận";
                }
            } catch(PDOException $e) {
                echo "Lỗi: " . $e->getMessage();
            }
        }
    }




