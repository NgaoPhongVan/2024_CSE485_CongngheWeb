<?php

class EmployeeController{
    public function HomeEmployee()
    {

    }
}