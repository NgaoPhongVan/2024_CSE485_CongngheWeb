<?php
require_once ROOT.'../service/departmentservice.php';
class DepartmentController{
    public function index(){
        $departmentservice = new departmentservice();
        $departments = $departmentservice->Getalldepartment();
        include ROOT.'../view/departments/index.php';
    }
    public function AddDepartment(){
        $id = $_POST['id'];
        $name = $_POST['name'];
        $phone = $_POST['phone'];
        $address = $_POST['address'];
        $email = $_POST['email'];
        $AddDepartment = new departmentservice();
        $AddDepart = $AddDepartment->AddDepartment($id,$name,$phone,$address,$email);
//        header('location:../app/index.php?controller=department&action=index');
    }
}
